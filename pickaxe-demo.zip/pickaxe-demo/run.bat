@echo off
setlocal EnableDelayedExpansion

REM ── Always run from the folder this .bat file lives in ──────
cd /d "%~dp0"

set VENV_DIR=.venv
set LOG_FILE=launch.log

REM ── Start logging everything to launch.log ──────────────────
call :log "============================================"
call :log "Pickaxe Analytics — Launch Log"
call :log "%DATE% %TIME%"
call :log "Working directory: %CD%"
call :log "============================================"

echo.
echo  Pickaxe Analytics — Demo Launcher
echo  Output is also saved to: %CD%\launch.log
echo ----------------------------------------

REM ── 1. Check Python ─────────────────────────────────────────
call :log "STEP 1: Checking Python..."
echo [1/5] Checking Python...

where python >nul 2>&1
if %errorlevel% neq 0 (
    call :log "ERROR: Python not found in PATH"
    echo.
    echo [ERROR] Python was not found.
    echo         Install Python 3.9+ from https://www.python.org/downloads/
    echo         During install, check "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PY_VER_FULL=%%i
call :log "Found: %PY_VER_FULL%"
echo        Found: %PY_VER_FULL%

REM ── 2. Check required files ──────────────────────────────────
call :log "STEP 2: Checking required files..."
echo [2/5] Checking required files...

for %%F in (.env requirements.txt vizdemov4_1_1.py) do (
    if not exist "%%F" (
        call :log "ERROR: Missing file: %%F"
        echo.
        echo [ERROR] Missing file: %%F
        echo         All files must be in the same folder as run.bat
        echo.
        pause
        exit /b 1
    ) else (
        call :log "  OK: %%F"
    )
)
echo        All required files found

REM ── 3. Create virtual environment ───────────────────────────
call :log "STEP 3: Virtual environment..."
echo [3/5] Setting up virtual environment...

if not exist "%VENV_DIR%\Scripts\activate.bat" (
    echo        Creating new virtual environment...
    python -m venv %VENV_DIR% >> %LOG_FILE% 2>&1
    if %errorlevel% neq 0 (
        call :log "ERROR: Failed to create virtual environment"
        echo.
        echo [ERROR] Failed to create virtual environment. See launch.log for details.
        echo.
        pause
        exit /b 1
    )
    call :log "  Created OK"
) else (
    call :log "  Already exists"
    echo        Already exists, skipping
)

REM ── 4. Activate and install dependencies ────────────────────
call :log "STEP 4: Installing dependencies..."
echo [4/5] Installing dependencies (first run takes a few minutes)...

call %VENV_DIR%\Scripts\activate.bat

python -m pip install --upgrade pip >> %LOG_FILE% 2>&1

pip install -r requirements.txt >> %LOG_FILE% 2>&1
if %errorlevel% neq 0 (
    call :log "ERROR: pip install failed"
    echo.
    echo [ERROR] Dependency installation failed.
    echo         Open launch.log in this folder to see the exact error.
    echo.
    pause
    exit /b 1
)
call :log "  Dependencies installed OK"
echo        Done

REM ── 5. Launch Streamlit ─────────────────────────────────────
call :log "STEP 5: Starting Streamlit..."
echo [5/5] Starting Streamlit...
echo.
echo  App will open at: http://localhost:8501
echo  If the browser does not open automatically, paste that URL into Chrome.
echo  Keep this window open. Press Ctrl+C to stop.
echo.

start "" cmd /c "timeout /t 5 /nobreak >nul && start http://localhost:8501"

streamlit run vizdemov4_1_1.py --server.port 8501 --server.headless false --browser.gatherUsageStats false

call :log "Streamlit exited"
echo.
echo  Streamlit stopped. If unexpected, open launch.log in this folder to see why.
echo.
pause
exit /b 0

:log
echo %~1 >> %LOG_FILE%
exit /b 0
