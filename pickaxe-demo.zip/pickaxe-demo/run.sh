#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  Pickaxe Analytics — One-Step Launcher (Mac / Linux)
#  Usage: bash run.sh
# ─────────────────────────────────────────────────────────────

set -e

VENV_DIR=".venv"
PYTHON_MIN_MAJOR=3
PYTHON_MIN_MINOR=9

# ── Terminal colors ───────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}[INFO]${RESET}  $*"; }
success() { echo -e "${GREEN}[OK]${RESET}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}  $*"; }
error()   { echo -e "${RED}[ERROR]${RESET} $*"; exit 1; }

echo ""
echo -e "${BOLD}⛏️  Pickaxe Analytics — Demo Launcher${RESET}"
echo "────────────────────────────────────────"

# ── 1. Check Python ───────────────────────────────────────────
info "Checking Python installation..."

if command -v python3 &>/dev/null; then
    PYTHON=python3
elif command -v python &>/dev/null; then
    PYTHON=python
else
    error "Python not found. Please install Python ${PYTHON_MIN_MAJOR}.${PYTHON_MIN_MINOR}+ from https://www.python.org/downloads/"
fi

PY_VERSION=$($PYTHON -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
PY_MAJOR=$($PYTHON -c "import sys; print(sys.version_info.major)")
PY_MINOR=$($PYTHON -c "import sys; print(sys.version_info.minor)")

if [ "$PY_MAJOR" -lt "$PYTHON_MIN_MAJOR" ] || \
   ([ "$PY_MAJOR" -eq "$PYTHON_MIN_MAJOR" ] && [ "$PY_MINOR" -lt "$PYTHON_MIN_MINOR" ]); then
    error "Python ${PYTHON_MIN_MAJOR}.${PYTHON_MIN_MINOR}+ required, but found ${PY_VERSION}. Please upgrade: https://www.python.org/downloads/"
fi
success "Python ${PY_VERSION} found"

# ── 2. Check .env file ────────────────────────────────────────
if [ ! -f ".env" ]; then
    error ".env file not found in this directory. Make sure it's placed alongside run.sh before launching."
fi
success ".env file found"

# ── 3. Create virtual environment (only if needed) ───────────
if [ ! -d "$VENV_DIR" ]; then
    info "Creating virtual environment..."
    $PYTHON -m venv "$VENV_DIR"
    success "Virtual environment created at ${VENV_DIR}/"
else
    info "Virtual environment already exists — skipping creation"
fi

# ── 4. Activate venv ─────────────────────────────────────────
source "$VENV_DIR/bin/activate"

# ── 5. Install / upgrade dependencies ────────────────────────
info "Installing dependencies (this may take a minute on first run)..."
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
success "All dependencies installed"

# ── 6. Launch Streamlit ───────────────────────────────────────
echo ""
echo -e "${BOLD}🚀 Starting Pickaxe Analytics...${RESET}"
echo -e "   Open your browser at ${CYAN}http://localhost:8501${RESET}"
echo -e "   Press ${BOLD}Ctrl+C${RESET} to stop the app"
echo ""

streamlit run vizdemov4_1_1.py \
    --server.headless true \
    --browser.gatherUsageStats false
