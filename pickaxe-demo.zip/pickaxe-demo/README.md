# ⛏️ Pickaxe Analytics — Demo Setup Guide

Two ways to run the app — pick whichever suits you best.

---

## Option A — Script (Python required)

This is the quickest path if you already have **Python 3.9+** installed.

> **Don't have Python?** Download it from [python.org/downloads](https://www.python.org/downloads/).  
> During installation on Windows, check ✅ **"Add Python to PATH"**.

### Steps

1. **Download and unzip** this folder somewhere on your computer (e.g. your Desktop).

2. **Make sure all four files are in the same folder:**
   ```
   vizdemov4_1_1.py
   requirements.txt
   .env
   run.sh   ← Mac / Linux
   run.bat  ← Windows
   ```

3. **Run the launcher:**

   | System | What to do |
   |--------|-----------|
   | **Mac / Linux** | Open Terminal, `cd` into the folder, then run: `bash run.sh` |
   | **Windows** | Double-click `run.bat` |

4. The script will automatically:
   - Create an isolated Python environment
   - Install all required packages
   - Start the Streamlit app

5. **Open your browser** to: **http://localhost:8501**

6. **To stop the app**, press `Ctrl+C` in the terminal / command prompt window.

> **Second run:** Startup is much faster because dependencies are already installed.

---

## Option B — Docker (no Python needed)

Use this if you'd prefer not to install Python, or want a fully isolated environment.

### Steps

1. Install **Docker Desktop** from [docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop/) and make sure it's running.

2. **Download and unzip** this folder. Confirm these files are present:
   ```
   vizdemov4_1_1.py
   requirements.txt
   .env
   Dockerfile
   docker-compose.yml
   ```

3. Open a terminal (Mac/Linux) or Command Prompt / PowerShell (Windows) and `cd` into the folder.

4. Run:
   ```
   docker compose up
   ```
   The first build takes a few minutes; subsequent starts are instant.

5. **Open your browser** to: **http://localhost:8501**

6. **To stop:** press `Ctrl+C`, then run `docker compose down`.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `command not found: python3` | Install Python from python.org, restart your terminal |
| `Permission denied: run.sh` | Run `chmod +x run.sh` first, then `bash run.sh` |
| Port 8501 already in use | Close any other Streamlit tabs/apps, or change the port in `run.sh`/`run.bat` |
| Docker: `Cannot connect to Docker daemon` | Make sure Docker Desktop is open and running |
| App loads but shows connection errors | Check that `.env` is in the same folder as the other files |

---

*Pickaxe Analytics — Fraud Intelligence Dashboard*
